package holamundo.examen_corto;

public class Vehiculo {
    private String codigo;
    private String descripcion;
    private String color;
    private double precio;
    
    public Vehiculo(String codigo, String descripcion, String color, double precio) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.color = color;
        this.precio = precio;
    }
    
    // Getters
    public String getCodigo() {
        return codigo;
    }
    
    public String getDescripcion() {
        return descripcion;
    }
    
    public String getColor() {
        return color;
    }
    
    public double getPrecio() {
        return precio;
    }
    
    // Setters
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public void setColor(String color) {
        this.color = color;
    }
    
    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    @Override
    public String toString() {
        return "Vehiculo{" + 
               "codigo='" + codigo + '\'' +
               ", descripcion='" + descripcion + '\'' +
               ", color='" + color + '\'' +
               ", precio=" + precio +
               '}';
    }
}