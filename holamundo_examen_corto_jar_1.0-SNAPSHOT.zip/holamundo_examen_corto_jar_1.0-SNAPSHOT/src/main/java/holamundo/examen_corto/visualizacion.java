
package holamundo.examen_corto;

import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class visualizacion extends javax.swing.JFrame {
    private ArrayList<Vehiculo> listaVehiculos;
    private DefaultTableModel modelo;

    public visualizacion() {
        initComponents();
        this.setLocationRelativeTo(null);
        listaVehiculos = new ArrayList<>();
        configurarTabla();
    }

    private void configurarTabla() {
        modelo = (DefaultTableModel) tabla1.getModel();
        modelo.setColumnCount(0);
        modelo.setRowCount(0);
        modelo.addColumn("Código");
        modelo.addColumn("Descripción");
        modelo.addColumn("Color");
        modelo.addColumn("Precio");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        botonguardar = new javax.swing.JButton();
        botonconsulta = new javax.swing.JButton();
        botonsalir = new javax.swing.JButton();
        txtdescripcion = new javax.swing.JTextField();
        txtcodigo = new javax.swing.JTextField();
        txtcolor = new javax.swing.JTextField();
        txtprecio = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabla1 = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Registro de Vehículos");

        jLabel1.setText("Código");
        jLabel2.setText("Descripción");
        jLabel3.setText("Color");
        jLabel4.setText("Precio");
        jLabel5.setText("REGISTRO DE VEHÍCULOS");
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18));

        botonguardar.setText("Guardar");
        botonguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonguardarActionPerformed(evt);
            }
        });

        botonconsulta.setText("Consultar");
        botonconsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonconsultaActionPerformed(evt);
            }
        });

        botonsalir.setText("Salir");
        botonsalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonsalirActionPerformed(evt);
            }
        });

        tabla1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {}
        ));
        jScrollPane2.setViewportView(tabla1);

        // Aquí va el código del diseño que ya tienes

        pack();
    }// </editor-fold>                        

    private void limpiarCampos() {
        txtcodigo.setText("");
        txtdescripcion.setText("");
        txtcolor.setText("");
        txtprecio.setText("");
        txtcodigo.requestFocus();
    }

    private boolean validarCampos() {
        if (txtcodigo.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El código es obligatorio");
            txtcodigo.requestFocus();
            return false;
        }
        if (txtdescripcion.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "La descripción es obligatoria");
            txtdescripcion.requestFocus();
            return false;
        }
        if (txtcolor.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El color es obligatorio");
            txtcolor.requestFocus();
            return false;
        }
        if (txtprecio.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El precio es obligatorio");
            txtprecio.requestFocus();
            return false;
        }
        try {
            Double.parseDouble(txtprecio.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El precio debe ser un número válido");
            txtprecio.requestFocus();
            return false;
        }
        return true;
    }

    private void botonguardarActionPerformed(java.awt.event.ActionEvent evt) {
        if (!validarCampos()) {
            return;
        }

        String codigo = txtcodigo.getText().trim();
        String descripcion = txtdescripcion.getText().trim();
        String color = txtcolor.getText().trim();
        double precio = Double.parseDouble(txtprecio.getText().trim());

        for (Vehiculo v : listaVehiculos) {
            if (v.getCodigo().equals(codigo)) {
                JOptionPane.showMessageDialog(this, "El código ya existe");
                txtcodigo.requestFocus();
                return;
            }
        }

        Vehiculo vehiculo = new Vehiculo(codigo, descripcion, color, precio);
        listaVehiculos.add(vehiculo);


        modelo.addRow(new Object[]{
            vehiculo.getCodigo(),
            vehiculo.getDescripcion(),
            vehiculo.getColor(),
            String.format("%.2f", vehiculo.getPrecio())
        });

        JOptionPane.showMessageDialog(this, "Vehículo guardado exitosamente");
        limpiarCampos();
    }

    private void botonconsultaActionPerformed(java.awt.event.ActionEvent evt) {
        String codigoBuscar = JOptionPane.showInputDialog(this, 
            "Ingrese el código del vehículo a buscar:",
            "Consultar Vehículo",
            JOptionPane.QUESTION_MESSAGE);

        if (codigoBuscar != null && !codigoBuscar.trim().isEmpty()) {
            boolean encontrado = false;
            for (Vehiculo v : listaVehiculos) {
                if (v.getCodigo().equals(codigoBuscar.trim())) {
                    txtcodigo.setText(v.getCodigo());
                    txtdescripcion.setText(v.getDescripcion());
                    txtcolor.setText(v.getColor());
                    txtprecio.setText(String.format("%.2f", v.getPrecio()));
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado) {
                JOptionPane.showMessageDialog(this,
                    "No se encontró ningún vehículo con el código: " + codigoBuscar,
                    "Vehículo no encontrado",
                    JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private void botonsalirActionPerformed(java.awt.event.ActionEvent evt) {
        int confirmar = JOptionPane.showConfirmDialog(this,
            "¿Está seguro que desea salir del programa?",
            "Confirmar Salida",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirmar == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(visualizacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            new visualizacion().setVisible(true);
        });
    }

                
}
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        botonguardar = new javax.swing.JButton();
        botonconsulta = new javax.swing.JButton();
        botonsalir = new javax.swing.JButton();
        txtdescripcion = new javax.swing.JTextField();
        txtcodigo = new javax.swing.JTextField();
        txtcolor = new javax.swing.JTextField();
        txtprecio = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabla1 = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("codigo");

        jLabel2.setText("descripcion");

        jLabel3.setText("color");

        jLabel4.setText("precio");

        botonguardar.setText("guardar");
        botonguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonguardarActionPerformed(evt);
            }
        });

        botonconsulta.setText("consultar");
        botonconsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonconsultaActionPerformed(evt);
            }
        });

        botonsalir.setText("salir");

        txtdescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtdescripcionActionPerformed(evt);
            }
        });

        txtcodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcodigoActionPerformed(evt);
            }
        });

        jLabel5.setText("registro de vehiculos");

        tabla1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tabla1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(85, 85, 85)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtdescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtcolor, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtprecio, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(208, 208, 208)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(botonguardar)
                        .addGap(40, 40, 40)
                        .addComponent(botonconsulta)
                        .addGap(67, 67, 67)
                        .addComponent(botonsalir))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(98, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(149, 149, 149)
                    .addComponent(txtcodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(297, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtdescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtcolor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtprecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonguardar)
                    .addComponent(botonconsulta)
                    .addComponent(botonsalir))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(44, 44, 44)
                    .addComponent(txtcodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(316, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtdescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtdescripcionActionPerformed
        
    }//GEN-LAST:event_txtdescripcionActionPerformed

    private void botonguardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonguardarActionPerformed

    }//GEN-LAST:event_botonguardarActionPerformed

    private void txtcodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcodigoActionPerformed
     
    }//GEN-LAST:event_txtcodigoActionPerformed

    private void botonconsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonconsultaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonconsultaActionPerformed

            }
        });
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonconsulta;
    private javax.swing.JButton botonguardar;
    private javax.swing.JButton botonsalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable tabla1;
    private javax.swing.JTextField txtcodigo;
    private javax.swing.JTextField txtcolor;
    private javax.swing.JTextField txtdescripcion;
    private javax.swing.JTextField txtprecio;
    // End of variables declaration//GEN-END:variables


